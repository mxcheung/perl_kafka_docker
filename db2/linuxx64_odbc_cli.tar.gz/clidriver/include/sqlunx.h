/******************************************************************************
 *
 * Source File Name = sqlunx.h
 *
 * (C) COPYRIGHT International Business Machines Corp. 1993, 2016
 * All Rights Reserved
 * Licensed Materials - Property of IBM
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * Function = Include File defining:
 *              DB2 CLI Interface - Constants
 *              DB2 CLI Interface - Function Prototypes
 *
 * Operating System = Common C Include File
 *
 *
 *****************************************************************************/


#include <sqlcli1.h>


